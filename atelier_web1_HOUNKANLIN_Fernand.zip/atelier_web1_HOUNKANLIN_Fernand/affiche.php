<?php
include "config.php";

$sql = "SELECT * FROM Etudiant";
$result = $conn->query($sql);

$Etudiant= [];

while ($row = $result->fetch_assoc()) {
    $Etudiant[] = $row;
}

echo json_encode($Etudiant);

$conn->close();
?>