<?php
include "connex.php";

$nom = $_POST['nom'];
$prenom = $_POST['prenom']; // Corrigé : ajout du ;
$email = $_POST['email'];
$telephone = $_POST['telephone'];
$filiere = $_POST['filiere']; // Corrigé : ajout du ;

$sql = "INSERT INTO Etudiant (nom, prenom, email, telephone, filiere)
        VALUES ('$nom', '$prenom', '$email', '$telephone', '$filiere')";

if ($conn->query($sql) === TRUE) {
    echo "Succès !";
} else {
    echo "Erreur : " . $conn->error;
}

$conn->close();
?>