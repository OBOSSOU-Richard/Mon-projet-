<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "projet";

$conn = new mysqli($host, $user, $password, $dbname);

// Vérification
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}
?>