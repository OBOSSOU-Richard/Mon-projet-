<?php include "connex.php"; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Etudiants</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    </style>
</head>
<body>
    <header>
        <h2>Liste des Étudiants</h2>
        <a href="form.html"><button>Ajouter un étudiant</button></a>
    </header>

    <table>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Filière</th>
        </tr>
        <?php
        $sql = "SELECT * FROM Etudiant";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['nom']}</td>
                    <td>{$row['prenom']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['filiere']}</td>
                  </tr>";
        }
        ?>
    </table>

    <footer>
        <center><p>© Gestion des Etudiants 2026</p></center>
    </footer>
</body>
</html>