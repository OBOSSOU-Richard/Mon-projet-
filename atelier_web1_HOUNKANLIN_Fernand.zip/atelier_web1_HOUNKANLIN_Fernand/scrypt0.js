document.getElementById("info").addEventListener("submit",function(e){
    e.preventDefault();
    let formData = new FormData(this);
    console.log('les infos du formulaire',formData);

    fetch("ajout.php", {
        method: "post",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        if (data === "success") {
            alert(" ajouté !");
            window.location.href = "index.html";
        }else{
            alert("Echec de l'ajout");
        }
    });
})