<?php
require_once 'config.php';

try {
    $stmt = $pdo->query("SELECT * FROM etudiant ORDER BY id DESC");
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($etudiant);
} catch (Exception $e) {
    echo json_encode([]);
}
?>