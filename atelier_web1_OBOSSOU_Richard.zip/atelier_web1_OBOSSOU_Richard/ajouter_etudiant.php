<?php

$host = 'localhost';
$dbname = 'liste_etudiant';
$user = 'root'; 
$pass = '';    

try {
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
     if (isset($_POST['nom'],   $_POST['Prénom']  ,$_POST['email'], $_POST['telephone'],  $_POST['email'], $_POST['Filiere']                ) ) {
        
        
        $sql = "INSERT INTO contacts (nom, email, telephone) VALUES (:nom, :email, :tel)";
        $stmt = $pdo->prepare($sql);

        
        $success = $stmt->execute([
            ':nom'   => $_POST['nom'],
            ':prenom' => $_POST['prenom'],
            ':email' => $_POST['email'],
            ':tel'   => $_POST['telephone']
            ':filière'   => $_POST['filière'],
        ]);

        if ($success) {
            
            header("Location: index.html?status=success");
            exit();
        }
    }
} catch (PDOException $e) {
    
    die("Erreur lors de l'enregistrement : " . $e->getMessage());}

?>