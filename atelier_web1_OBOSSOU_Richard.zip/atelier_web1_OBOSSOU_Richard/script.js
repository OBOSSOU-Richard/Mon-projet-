async function chargerEtudiant() {
    const tableBody = document.getElementById('etudiantTableBody');
    try {
        const response = await fetch('afficher_etudiant.php');
        const contacts = await response.json();
        
        tableBody.innerHTML = '';

        contacts.forEach(etudiant => {
            const row = `
                <tr>
                    <td>${etudiant.nom}</td>
                    <td>${etudiant.email}</td>
                    <td>${etudiant.telephone}</td>
                    <td>
                        <button onclick="supprimeretudiant(${etudiant.id})" style="color:red">Supprimer</button>
                    </td>
                </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error("Erreur de chargement :", error);
    }
}

window.onload = chargerEtudiant;

async function supprimerEtudiant(id) {
    if (confirm("Supprimer cet étudiant ?")) {
        await fetch(`supprimer_etudiant.php?id=${id}`);
        chargerEtudiant();
    }
}